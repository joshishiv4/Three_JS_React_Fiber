import './App.css'

import Three from './three'

function App() {

  return (
    <>
      <Three/>
    </>
  )
}

export default App
